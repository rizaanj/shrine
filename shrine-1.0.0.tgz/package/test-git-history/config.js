// API configuration (removed secret, using env var)
const config = {
  apiKey: process.env.API_KEY,
  endpoint: 'https://api.example.com'
};

module.exports = config;
